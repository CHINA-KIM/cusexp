<?php
global $PORTF1, $PORTF2, $PORTF3, $PORTF4, $PORTF5, $PORTF6;
global $address_tra,$email,$phone_tra;
// 初始化图片路径
$PORTF1 = "../img/portfolio-1.jpg";
$PORTF2 = "../img/portfolio-2.jpg";
$PORTF3 = "../img/portfolio-3.jpg";
$PORTF4 = "../img/portfolio-4.jpg";
$PORTF5 = "../img/portfolio-5.jpg";
$PORTF6 = "../img/portfolio-6.jpg";

$address_tra = "中華人民共和國香港特別行政區";
$email_tra = "email@email.com";
$phone_tra = "+8520000001";
