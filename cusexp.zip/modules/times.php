<?php

// 假设基准年份是2001年
$baseYear = 2001;

// 获取当前年份日期
$currentYear = date("Y");

// 计算年度序号
$yearNumber = $currentYear - $baseYear + 1;



